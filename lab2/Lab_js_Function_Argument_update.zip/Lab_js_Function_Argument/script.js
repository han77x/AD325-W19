function addTwoNumbers() {
   	var a = 5;
	var b = 10;
	var result = a + b;
	alert(result);
}

addTwoNumbers();
